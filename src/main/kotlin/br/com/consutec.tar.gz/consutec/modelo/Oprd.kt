package br.com.consutec.modelo

import java.math.BigDecimal

class Oprd {
  var prdno: String? = null
  var grade: String? = null
  var descricao: String? = null
  var qtd: BigDecimal? = null
}